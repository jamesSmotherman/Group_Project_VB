﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CalendarGenerator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MonthComboBox = New System.Windows.Forms.ComboBox()
        Me.DoWComboBox = New System.Windows.Forms.ComboBox()
        Me.YearTextBox = New System.Windows.Forms.TextBox()
        Me.GenerateButton = New System.Windows.Forms.Button()
        Me.MonthLabel = New System.Windows.Forms.Label()
        Me.DoWLabel = New System.Windows.Forms.Label()
        Me.YearLabel = New System.Windows.Forms.Label()
        Me.CalendarLabel = New System.Windows.Forms.Label()
        Me.ResetButton = New System.Windows.Forms.Button()
        Me.ShowHideButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'MonthComboBox
        '
        Me.MonthComboBox.FormattingEnabled = True
        Me.MonthComboBox.Location = New System.Drawing.Point(11, 86)
        Me.MonthComboBox.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.MonthComboBox.Name = "MonthComboBox"
        Me.MonthComboBox.Size = New System.Drawing.Size(98, 21)
        Me.MonthComboBox.TabIndex = 0
        '
        'DoWComboBox
        '
        Me.DoWComboBox.FormattingEnabled = True
        Me.DoWComboBox.Location = New System.Drawing.Point(12, 134)
        Me.DoWComboBox.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.DoWComboBox.Name = "DoWComboBox"
        Me.DoWComboBox.Size = New System.Drawing.Size(98, 21)
        Me.DoWComboBox.TabIndex = 1
        '
        'YearTextBox
        '
        Me.YearTextBox.Location = New System.Drawing.Point(10, 42)
        Me.YearTextBox.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.YearTextBox.Name = "YearTextBox"
        Me.YearTextBox.Size = New System.Drawing.Size(100, 20)
        Me.YearTextBox.TabIndex = 2
        '
        'GenerateButton
        '
        Me.GenerateButton.BackColor = System.Drawing.Color.Lime
        Me.GenerateButton.Location = New System.Drawing.Point(2, 1)
        Me.GenerateButton.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.GenerateButton.Name = "GenerateButton"
        Me.GenerateButton.Size = New System.Drawing.Size(330, 24)
        Me.GenerateButton.TabIndex = 4
        Me.GenerateButton.Text = "Generate Calendar"
        Me.GenerateButton.UseVisualStyleBackColor = False
        '
        'MonthLabel
        '
        Me.MonthLabel.AutoSize = True
        Me.MonthLabel.Location = New System.Drawing.Point(10, 71)
        Me.MonthLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.MonthLabel.Name = "MonthLabel"
        Me.MonthLabel.Size = New System.Drawing.Size(40, 13)
        Me.MonthLabel.TabIndex = 5
        Me.MonthLabel.Text = "Month:"
        '
        'DoWLabel
        '
        Me.DoWLabel.AutoSize = True
        Me.DoWLabel.Location = New System.Drawing.Point(10, 119)
        Me.DoWLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.DoWLabel.Name = "DoWLabel"
        Me.DoWLabel.Size = New System.Drawing.Size(73, 13)
        Me.DoWLabel.TabIndex = 6
        Me.DoWLabel.Text = "Day-of-Week:"
        '
        'YearLabel
        '
        Me.YearLabel.AutoSize = True
        Me.YearLabel.Location = New System.Drawing.Point(10, 26)
        Me.YearLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.YearLabel.Name = "YearLabel"
        Me.YearLabel.Size = New System.Drawing.Size(32, 13)
        Me.YearLabel.TabIndex = 7
        Me.YearLabel.Text = "Year:"
        '
        'CalendarLabel
        '
        Me.CalendarLabel.AutoSize = True
        Me.CalendarLabel.Font = New System.Drawing.Font("Courier New", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CalendarLabel.Location = New System.Drawing.Point(122, 47)
        Me.CalendarLabel.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.CalendarLabel.Name = "CalendarLabel"
        Me.CalendarLabel.Size = New System.Drawing.Size(35, 14)
        Me.CalendarLabel.TabIndex = 8
        Me.CalendarLabel.Text = "NULL"
        Me.CalendarLabel.Visible = False
        '
        'ResetButton
        '
        Me.ResetButton.BackColor = System.Drawing.Color.Red
        Me.ResetButton.Location = New System.Drawing.Point(2, 176)
        Me.ResetButton.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ResetButton.Name = "ResetButton"
        Me.ResetButton.Size = New System.Drawing.Size(162, 24)
        Me.ResetButton.TabIndex = 9
        Me.ResetButton.Text = "Reset"
        Me.ResetButton.UseVisualStyleBackColor = False
        '
        'ShowHideButton
        '
        Me.ShowHideButton.BackColor = System.Drawing.Color.Fuchsia
        Me.ShowHideButton.Location = New System.Drawing.Point(168, 176)
        Me.ShowHideButton.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ShowHideButton.Name = "ShowHideButton"
        Me.ShowHideButton.Size = New System.Drawing.Size(164, 24)
        Me.ShowHideButton.TabIndex = 10
        Me.ShowHideButton.Text = "Show / Hide Calendar"
        Me.ShowHideButton.UseVisualStyleBackColor = False
        '
        'CalendarGenerator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.ClientSize = New System.Drawing.Size(334, 201)
        Me.Controls.Add(Me.ShowHideButton)
        Me.Controls.Add(Me.ResetButton)
        Me.Controls.Add(Me.CalendarLabel)
        Me.Controls.Add(Me.YearLabel)
        Me.Controls.Add(Me.DoWLabel)
        Me.Controls.Add(Me.MonthLabel)
        Me.Controls.Add(Me.GenerateButton)
        Me.Controls.Add(Me.YearTextBox)
        Me.Controls.Add(Me.DoWComboBox)
        Me.Controls.Add(Me.MonthComboBox)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.MaximizeBox = False
        Me.Name = "CalendarGenerator"
        Me.Text = "Calendar Generator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MonthComboBox As ComboBox
    Friend WithEvents DoWComboBox As ComboBox
    Friend WithEvents YearTextBox As TextBox
    Friend WithEvents GenerateButton As Button
    Friend WithEvents MonthLabel As Label
    Friend WithEvents DoWLabel As Label
    Friend WithEvents YearLabel As Label
    Friend WithEvents CalendarLabel As Label
    Friend WithEvents ResetButton As Button
    Friend WithEvents ShowHideButton As Button
End Class
