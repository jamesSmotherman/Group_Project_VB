﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CalendarGenerator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MonthComboBox = New System.Windows.Forms.ComboBox()
        Me.DoWComboBox = New System.Windows.Forms.ComboBox()
        Me.YearTextBox = New System.Windows.Forms.TextBox()
        Me.GenerateButton = New System.Windows.Forms.Button()
        Me.MonthLabel = New System.Windows.Forms.Label()
        Me.DoWLabel = New System.Windows.Forms.Label()
        Me.YearLabel = New System.Windows.Forms.Label()
        Me.CalendarLabel = New System.Windows.Forms.Label()
        Me.ResetButton = New System.Windows.Forms.Button()
        Me.ShowHideButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'MonthComboBox
        '
        Me.MonthComboBox.FormattingEnabled = True
        Me.MonthComboBox.Location = New System.Drawing.Point(15, 98)
        Me.MonthComboBox.Name = "MonthComboBox"
        Me.MonthComboBox.Size = New System.Drawing.Size(121, 24)
        Me.MonthComboBox.TabIndex = 0
        '
        'DoWComboBox
        '
        Me.DoWComboBox.FormattingEnabled = True
        Me.DoWComboBox.Location = New System.Drawing.Point(15, 145)
        Me.DoWComboBox.Name = "DoWComboBox"
        Me.DoWComboBox.Size = New System.Drawing.Size(121, 24)
        Me.DoWComboBox.TabIndex = 1
        '
        'YearTextBox
        '
        Me.YearTextBox.Location = New System.Drawing.Point(12, 53)
        Me.YearTextBox.Name = "YearTextBox"
        Me.YearTextBox.Size = New System.Drawing.Size(100, 22)
        Me.YearTextBox.TabIndex = 2
        '
        'GenerateButton
        '
        Me.GenerateButton.Location = New System.Drawing.Point(0, 0)
        Me.GenerateButton.Name = "GenerateButton"
        Me.GenerateButton.Size = New System.Drawing.Size(482, 30)
        Me.GenerateButton.TabIndex = 4
        Me.GenerateButton.Text = "Generate Calendar"
        Me.GenerateButton.UseVisualStyleBackColor = True
        '
        'MonthLabel
        '
        Me.MonthLabel.AutoSize = True
        Me.MonthLabel.Location = New System.Drawing.Point(12, 78)
        Me.MonthLabel.Name = "MonthLabel"
        Me.MonthLabel.Size = New System.Drawing.Size(51, 17)
        Me.MonthLabel.TabIndex = 5
        Me.MonthLabel.Text = "Month:"
        '
        'DoWLabel
        '
        Me.DoWLabel.AutoSize = True
        Me.DoWLabel.Location = New System.Drawing.Point(12, 125)
        Me.DoWLabel.Name = "DoWLabel"
        Me.DoWLabel.Size = New System.Drawing.Size(95, 17)
        Me.DoWLabel.TabIndex = 6
        Me.DoWLabel.Text = "Day-of-Week:"
        '
        'YearLabel
        '
        Me.YearLabel.AutoSize = True
        Me.YearLabel.Location = New System.Drawing.Point(12, 33)
        Me.YearLabel.Name = "YearLabel"
        Me.YearLabel.Size = New System.Drawing.Size(42, 17)
        Me.YearLabel.TabIndex = 7
        Me.YearLabel.Text = "Year:"
        '
        'CalendarLabel
        '
        Me.CalendarLabel.AutoSize = True
        Me.CalendarLabel.Font = New System.Drawing.Font("Courier New", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CalendarLabel.Location = New System.Drawing.Point(143, 58)
        Me.CalendarLabel.Name = "CalendarLabel"
        Me.CalendarLabel.Size = New System.Drawing.Size(40, 16)
        Me.CalendarLabel.TabIndex = 8
        Me.CalendarLabel.Text = "NULL"
        Me.CalendarLabel.Visible = False
        '
        'ResetButton
        '
        Me.ResetButton.Location = New System.Drawing.Point(0, 272)
        Me.ResetButton.Name = "ResetButton"
        Me.ResetButton.Size = New System.Drawing.Size(241, 30)
        Me.ResetButton.TabIndex = 9
        Me.ResetButton.Text = "Reset"
        Me.ResetButton.UseVisualStyleBackColor = True
        '
        'ShowHideButton
        '
        Me.ShowHideButton.Location = New System.Drawing.Point(241, 272)
        Me.ShowHideButton.Name = "ShowHideButton"
        Me.ShowHideButton.Size = New System.Drawing.Size(241, 30)
        Me.ShowHideButton.TabIndex = 10
        Me.ShowHideButton.Text = "Show / Hide Calendar"
        Me.ShowHideButton.UseVisualStyleBackColor = True
        '
        'CalendarGenerator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(120.0!, 120.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.ClientSize = New System.Drawing.Size(482, 303)
        Me.Controls.Add(Me.ShowHideButton)
        Me.Controls.Add(Me.ResetButton)
        Me.Controls.Add(Me.CalendarLabel)
        Me.Controls.Add(Me.YearLabel)
        Me.Controls.Add(Me.DoWLabel)
        Me.Controls.Add(Me.MonthLabel)
        Me.Controls.Add(Me.GenerateButton)
        Me.Controls.Add(Me.YearTextBox)
        Me.Controls.Add(Me.DoWComboBox)
        Me.Controls.Add(Me.MonthComboBox)
        Me.MaximizeBox = False
        Me.Name = "CalendarGenerator"
        Me.Text = "Calendar Generator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MonthComboBox As ComboBox
    Friend WithEvents DoWComboBox As ComboBox
    Friend WithEvents YearTextBox As TextBox
    Friend WithEvents GenerateButton As Button
    Friend WithEvents MonthLabel As Label
    Friend WithEvents DoWLabel As Label
    Friend WithEvents YearLabel As Label
    Friend WithEvents CalendarLabel As Label
    Friend WithEvents ResetButton As Button
    Friend WithEvents ShowHideButton As Button
End Class
