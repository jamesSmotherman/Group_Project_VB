﻿' Team 1:
' Christopher Anderson
' David Tippy
' James Smotherman
' Lancaster Graham
'


' Project:
' Calendar Generator

Public Class CalendarGenerator

    Private Sub CalendarGenerator_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Populate combo boxs here
    End Sub

    Private Sub GenerateButton_Click(sender As Object, e As EventArgs) Handles GenerateButton.Click
        ' Check If User Input Valid Here
        ' POSSIBLE SOLUTION -  loop with &= concat on CalendarLabel.Text
        ' Courier New font is all the same width
        CalendarLabel.Text = "This Is The Month Year Line" + vbCrLf + "SUN MON TUE WED THR FRI SAT" + vbCrLf + "Sun Mon Tue Wed Thr Fri Sat"
        CalendarLabel.Visible = True
    End Sub

End Class
