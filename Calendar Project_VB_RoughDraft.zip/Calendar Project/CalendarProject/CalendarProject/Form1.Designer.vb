﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.YearBox = New System.Windows.Forms.TextBox()
        Me.YearLabel = New System.Windows.Forms.Label()
        Me.MonthLabel = New System.Windows.Forms.Label()
        Me.MonthSelector = New System.Windows.Forms.ComboBox()
        Me.DaySelector = New System.Windows.Forms.ComboBox()
        Me.DayLabel = New System.Windows.Forms.Label()
        Me.YearMonthLabel = New System.Windows.Forms.Label()
        Me.DaysOfWeekLabel = New System.Windows.Forms.Label()
        Me.CalendarLabel = New System.Windows.Forms.Label()
        Me.CalendarButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'YearBox
        '
        Me.YearBox.Location = New System.Drawing.Point(57, 91)
        Me.YearBox.Name = "YearBox"
        Me.YearBox.Size = New System.Drawing.Size(100, 20)
        Me.YearBox.TabIndex = 0
        '
        'YearLabel
        '
        Me.YearLabel.AutoSize = True
        Me.YearLabel.Location = New System.Drawing.Point(77, 54)
        Me.YearLabel.Name = "YearLabel"
        Me.YearLabel.Size = New System.Drawing.Size(57, 13)
        Me.YearLabel.TabIndex = 1
        Me.YearLabel.Text = "Enter Year"
        '
        'MonthLabel
        '
        Me.MonthLabel.AutoSize = True
        Me.MonthLabel.Location = New System.Drawing.Point(269, 54)
        Me.MonthLabel.Name = "MonthLabel"
        Me.MonthLabel.Size = New System.Drawing.Size(70, 13)
        Me.MonthLabel.TabIndex = 2
        Me.MonthLabel.Text = "Select Month"
        '
        'MonthSelector
        '
        Me.MonthSelector.FormattingEnabled = True
        Me.MonthSelector.Location = New System.Drawing.Point(224, 90)
        Me.MonthSelector.Name = "MonthSelector"
        Me.MonthSelector.Size = New System.Drawing.Size(121, 21)
        Me.MonthSelector.TabIndex = 3
        '
        'DaySelector
        '
        Me.DaySelector.FormattingEnabled = True
        Me.DaySelector.Location = New System.Drawing.Point(442, 89)
        Me.DaySelector.Name = "DaySelector"
        Me.DaySelector.Size = New System.Drawing.Size(121, 21)
        Me.DaySelector.TabIndex = 4
        '
        'DayLabel
        '
        Me.DayLabel.AutoSize = True
        Me.DayLabel.Location = New System.Drawing.Point(481, 53)
        Me.DayLabel.Name = "DayLabel"
        Me.DayLabel.Size = New System.Drawing.Size(59, 13)
        Me.DayLabel.TabIndex = 5
        Me.DayLabel.Text = "Select Day"
        '
        'YearMonthLabel
        '
        Me.YearMonthLabel.AutoSize = True
        Me.YearMonthLabel.Location = New System.Drawing.Point(258, 232)
        Me.YearMonthLabel.Name = "YearMonthLabel"
        Me.YearMonthLabel.Size = New System.Drawing.Size(23, 13)
        Me.YearMonthLabel.TabIndex = 6
        Me.YearMonthLabel.Text = "null"
        '
        'DaysOfWeekLabel
        '
        Me.DaysOfWeekLabel.AutoSize = True
        Me.DaysOfWeekLabel.Location = New System.Drawing.Point(192, 259)
        Me.DaysOfWeekLabel.Name = "DaysOfWeekLabel"
        Me.DaysOfWeekLabel.Size = New System.Drawing.Size(153, 13)
        Me.DaysOfWeekLabel.TabIndex = 7
        Me.DaysOfWeekLabel.Text = "Sun Mon Tue Wed Thu Fri Sat"
        Me.DaysOfWeekLabel.Visible = False
        '
        'CalendarLabel
        '
        Me.CalendarLabel.AutoSize = True
        Me.CalendarLabel.Location = New System.Drawing.Point(192, 283)
        Me.CalendarLabel.Name = "CalendarLabel"
        Me.CalendarLabel.Size = New System.Drawing.Size(0, 13)
        Me.CalendarLabel.TabIndex = 8
        '
        'CalendarButton
        '
        Me.CalendarButton.Location = New System.Drawing.Point(80, 155)
        Me.CalendarButton.Name = "CalendarButton"
        Me.CalendarButton.Size = New System.Drawing.Size(135, 23)
        Me.CalendarButton.TabIndex = 9
        Me.CalendarButton.Text = "CalendarMaker"
        Me.CalendarButton.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.CalendarButton)
        Me.Controls.Add(Me.CalendarLabel)
        Me.Controls.Add(Me.DaysOfWeekLabel)
        Me.Controls.Add(Me.YearMonthLabel)
        Me.Controls.Add(Me.DayLabel)
        Me.Controls.Add(Me.DaySelector)
        Me.Controls.Add(Me.MonthSelector)
        Me.Controls.Add(Me.MonthLabel)
        Me.Controls.Add(Me.YearLabel)
        Me.Controls.Add(Me.YearBox)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents YearBox As TextBox
    Friend WithEvents YearLabel As Label
    Friend WithEvents MonthLabel As Label
    Friend WithEvents MonthSelector As ComboBox
    Friend WithEvents DaySelector As ComboBox
    Friend WithEvents DayLabel As Label
    Friend WithEvents YearMonthLabel As Label
    Friend WithEvents DaysOfWeekLabel As Label
    Friend WithEvents CalendarLabel As Label
    Friend WithEvents CalendarButton As Button
End Class
